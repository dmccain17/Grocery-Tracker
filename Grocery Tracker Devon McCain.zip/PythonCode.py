import re
import string
import os.path
from os import path


# Calls a function to pass the function nme into CallProcedures

def CountAll():
    # Opens the file to be read
    text = open("CS210_Project_Three_Input_File.txt", "r")

    #Creates an empty dictionary to store the words
    dictionary = dict()

    #Check each line of the input file and removes extra spaces and or newline characters.
    for line in text:
        line = line.strip()

        #Converts all of the characters to lowercase so the program can match better.
        word = line.lower()
        
        #Check if the word is already in the dictionary and then increments the number of times that the word appears.
        if word in dictionary:
            dictionary[word] = dictionary[word] + 1
        else:
            #If the word is not in the dictionary, then it gets added value of 1
            dictionary[word] = 1

    #Print all of the contents from the dictionary
    for key in list (dictionary.keys()):
        print(key.capitalize(), ":", dictionary[key])

    #Closes the opened file.
    text.close()


#Call this function to pass it into CallIntFunc with the search term. Then returns the number of occurances of each term.
def CountInstances(searchTerm):

    #Converts each search term to lowercase for better matching within the program.
    searchTerm = searchTerm.lower()

    #Opens file in read mode and creates a variable to track the amount of times the search term has been found.
    text = open("CS210_Project_Three_Input_File.txt", "r")
    wordCount = 0

    #Check each line of the input file and can remove any extra spaces or newlines + lowercase conversion.
    for line in text:
        line = line.strip()
        word = line.lower()
        
        #Checks to see if the found word is equal to the user's input and then increments the number of times it appears.
        if word == searchTerm:
            wordCount += 1

    return wordCount

    #Closes the opened file
    text.close()



#Passes this functino into the CallProcedure function. 
#This then returns a document with each word ad the number of times that it has occured.

def CollectData():
    #Open the file in read mode. Then creates/writes a the file frequency.dat.
    text = open("CS210_Project_Three_Input_File.txt", "r")
    frequency = open("frequency.dat", "w")

    #Creates an empty dictionary to store the words. This then checks each line of the input file and removes any extra characters.
    dictionary = dict()

    for line in text:
        line = line.strip()

        #Converts characters to lowercase
        word = line.lower()
        
        #Checks if the word is already in the dictionary and increments the number of times that the word has appeared.
        if word in dictionary:
            dictionary[word] = dictionary[word] + 1
        else:
            #If the word is not in the dictionary, it increments by 1.
            dictionary[word] = 1

    #Write each key and value pair to frequency.dat
    for key in list (dictionary.keys()):
        #Formats the key value pair as strings with a newline.
        frequency.write(str(key.capitalize()) + " " + str(dictionary[key]) + "\n")

    #Closes the opened files
    text.close()
    frequency.close()
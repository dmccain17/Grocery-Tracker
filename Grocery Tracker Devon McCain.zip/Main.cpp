#include <Python.py>
#include <iostream>
#include <iomanip>
#define NOMINMAX
#include <Windows.h>
#undef NOMINMAX
#include <cmath>
#include <string>
#include <fstream>

using namespace std;


//Passes the function with the function name in Python that is wanted to be called.
void CallProcedure(string pName)
{
    char* procname = new char[pName.length() + 1];
    std::strcpy(procname, pName.c_str());

    Py_Initialize();
    PyObject* my_module = PyImport_ImportModule("PythonCode");
    PyErr_Print();
    PyObject* my_function = PyObject_GetAttrString(my_module, procname);
    PyObject* my_result = PyObject_CallObject(my_function, NULL);
    Py_Finalize();

    delete[] procname;
}

//Passes the name of the Python function that is needed to be called with the string paramenter.
int callIntFunc(string proc, string param)
{
    char* procname = new char[proc.length() + 1];
    std::strcpy(procname, proc.c_str());

    char* paramval = new char[param.length() + 1];
    std::strcpy(paramval, param.c_str());


    PyObject* pName, * pModule, * pDict, * pFunc, * pValue = nullptr, * presult = nullptr;
    // Initialize the Python Interpreter and builds the name object
    Py_Initialize();
    pName = PyUnicode_FromString((char*)"PythonCode");
    // Load the module object and pDict is then a borrowed reference
    pModule = PyImport_Import(pName);
    pDict = PyModule_GetDict(pModule);
    // pFunc is then also a borrowed reference 
    pFunc = PyDict_GetItemString(pDict, procname);
    if (PyCallable_Check(pFunc))
    {
        pValue = Py_BuildValue("(z)", paramval);
        PyErr_Print();
        presult = PyObject_CallObject(pFunc, pValue);
        PyErr_Print();
    }
    else
    {
        PyErr_Print();
    }
    Py_DECREF(pValue);
    Py_DECREF(pModule);
    Py_DECREF(pName);
    Py_Finalize();

    delete[] procname;
    delete[] paramval;

    return _PyLong_AsInt(presult);
}


//Passes he name of the needed function with the string pararmenter.
int callIntFunc(string proc, int param)
{
    char* procname = new char[proc.length() + 1];
    std::strcpy(procname, proc.c_str());

    PyObject* pName, * pModule, * pDict, * pFunc, * pValue = nullptr, * presult = nullptr;
    // Initialize the Python Interpreter and builds name object
    Py_Initialize();
    pName = PyUnicode_FromString((char*)"PythonCode");
    // Load the module object and the borrowed references.
    pModule = PyImport_Import(pName);
    pDict = PyModule_GetDict(pModule);
    pFunc = PyDict_GetItemString(pDict, procname);
    if (PyCallable_Check(pFunc))
    {
        pValue = Py_BuildValue("(i)", param);
        PyErr_Print();
        presult = PyObject_CallObject(pFunc, pValue);
        PyErr_Print();
    }
    else
    {
        PyErr_Print();
    }
    Py_DECREF(pValue);
    Py_DECREF(pModule);
    Py_DECREF(pName);
    Py_Finalize();

    delete[] procname;

    return _PyLong_AsInt(presult);
}


//This function can produce a menu o prompt the user for input
void DrawMenu() {

    //Initializes the method-specific variables
    int menuLoop = 0;                                   //Tracks # of menu loops
    int wordCount = 0;                                  //Tracks # of times a specific word was found
    int itemQuantity = 0;                               //Variable to contain an item quantity from frequency.dat
    string searchTerm;                                  //Collects user input for the term being searched
    string itemName;                                    //Variable to contain an item name from frequency.dat
    string greenColor = "\033[32;1m";                   //Sets the font color to green for the histogram asterisks
    string defaultColor = "\033[0m";                    //Sets the default font color for the console
    ifstream fileInput;                                 //Opens the ifstream for file

    while (menuLoop != 4) {

        //This prompts the user for input and then takes that input.
        std::cout << "[1] Calculate the number of times each item appears" << std::endl;
        std::cout << "[2] Calculate the frequency of a specific item" << std::endl;
        std::cout << "[3] Create a histogram based on the number of appearances of each item" << std::endl;
        std::cout << "[4] Quit" << std::endl;

        std::cin >> menuLoop;

        //Checks the user input. If not correct, it will reprompt.
        while (std::cin.fail()) {
            std::cin.clear();
            std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
            std::cout << "Please input a valid selection: ";
            std::cin >> menuLoop;
        }


        switch (menuLoop) {

            //
            //Case 1: Calculate the number of times each item appears, then print a list
            //This case calculates the # of times each item will appear, and then prints a list.
        case 1:
            system("CLS");                                          
            CallProcedure("CountAll");                      
            std::cout << std::endl;                           
            break;

            //This case calculates the # of times an item appears, and then prints the result of that number.
        case 2:
            system("CLS");
            std::cout << "What item would you like to search for?" << std::endl;
            std::cin >> searchTerm;

            //Calls the function with the serach term and then returns the integer word count value
            wordCount = callIntFunc("CountInstances", searchTerm);

            //Print statement with the returned word count
            std::cout << std::endl << searchTerm << " : " << wordCount << std::endl << std::endl;

            break;

            //This case will print the histogram with each time an item will appear.
        case 3:
            system("CLS");                                          
            CallProcedure("CollectData");           

            fileInput.open("frequency.dat");        

            fileInput >> itemName;                            
            fileInput >> itemQuantity;                        

            //With every line, print a histogram. After each has been parsed, it then will break
            while (!fileInput.fail()) {
                //Sets text color to the default
                std::cout << defaultColor;

                //Prints the item name and then prepares it for the histogram
                std::cout << std::setw(14) << std::left << itemName << std::setw(6);

                //Sets the histogram color
                std::cout << greenColor;

                //Prints the itemQuantity number of asterisks
                for (int i = 0; i < itemQuantity; i++) {

                    //Print green asterisks in line
                    std::cout << std::right << "*";
                }
                //Prepares for the next line and then sets the next item's name and quantity
                std::cout << std::endl;
                fileInput >> itemName;
                fileInput >> itemQuantity;
            }

            //Closes frequency.dat, reset font color, then break
            fileInput.close();
            std::cout << defaultColor << endl;
            break;

            //This last case will exit the program
        case 4:
            return;

            //Default case for invalid input
        default:
            std::cout << "Please input a valid selection.";
            std::cout << std::endl;
            break;
        }
    }
}

//The Main method will call the DrawMenu method to collect the user input
void main()
{
    //Draws the user menu
    DrawMenu();

}